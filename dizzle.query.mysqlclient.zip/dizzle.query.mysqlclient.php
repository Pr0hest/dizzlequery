<?php

	// Password Settings .. Set this to the same password you created in your app.
	$password = "";
	
	// Error Handler
	$error = false;

	// Post variables coming in from the app
	$host = $_POST["host"];
	$port = $_POST["port"];
	$user = $_POST["user"];
	$pass = $_POST["password"];
	$database = $_POST["database"];
	$query = $_POST["query"];
	$view = (isset($_POST["view"])) ? "--".$_POST["view"] : "--html";

	// Password Check
	if(!empty($password) || !empty($_POST["remotePassword"])) {
		if($_POST["remotePassword"] != md5($password)) {
			$error = true;
			$returnMessage = "<p class='error'>The passwords between the app and your processor don't match.</p>";
		}
	}


	// Handle the mysql command query
	if($error == true) {
		// We'll fail out here instead of below to be more secure
		echo $returnMessage;
		exit;
	}
	elseif(empty($query)) {
		$returnMessage = "You didn't ask me anything ...";
	} 
	else {
		// Cleanup the query, making sure we have a good string
		$query = trim($query);

		// Check for a select and set the limit to 1000 to help with speed and rendering
		$queryParts = explode(" ", $query);
		if(strtolower($queryParts[0]) == "select" && !stristr($query, "limit")) {
			$query = $query . " limit 1000";
		}

		// Single quotes can break the command so we escape them
		$query = str_replace("'", '"', $query);

		// If there isn't a specified port we use the default
		if(empty($port) || $port == "null") $port = 3306;
	
		// Run our command
		$command = "mysql -h $host -u$user -p$pass -P $port $view -e '$query' --max_allowed_packet=10K $database 2>&1";
		$results = exec($command, $output, $error);
	}


	// Display errors if there are any, along with any manual return messages
	if(!empty($returnMessage)) {
		echo "<p class='error'>$returnMessage</p>";
		exit;
	}
	elseif (!empty($error)) {
		$errorMessage = explode(":", $output[0]);
		echo "<p class='error'>ERROR</p>";
		echo "<p class='error'>" . $errorMessage[1] . "</p>";
		exit;
	}
	else {

		// The --html option returns data formatted as a basic table. If you would like to alter this script to not use the mysql command, but different scripting, simply loop through the rows and create standard html table rows. 
		foreach($output as $o) {
			echo $o;
		}
	}

?>
