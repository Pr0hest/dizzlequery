<?php

	// Error Reporting .. turns it off
	ini_set("display_errors", 0);

	// Password Settings .. Set this to the same password you created in your app.
	$password = "";
	
	// Post variables coming in from the app
	$host = $_POST["host"];
	$port = $_POST["port"];
	$user = $_POST["user"];
	$pass = $_POST["password"];
	$database = $_POST["database"];
	$query = $_POST["query"];
	$view = (isset($_POST["view"])) ? "--".$_POST["view"] : "--html";

	// Password Check
	if(!empty($password) || !empty($_POST["remotePassword"])) {
		if($_POST["remotePassword"] != md5($password)) {
			die(showError("The passwords between the app and your processor don't match."));
		}
	}	


	// Handle the mysql command query
	if(empty($query)) {
		die(showError("You didn't ask me anything ..."));
	} 
	else {
		// Cleanup the query, making sure we have a good string
		$query = trim($query);

		// Check for a select and set the limit to 1000 to help with speed and rendering
		$queryParts = explode(" ", $query);
		if(strtolower($queryParts[0]) == "select" && !stristr($query, "limit")) {
			$query = $query . " limit 1000";
		}

		// Single quotes can break the command so we escape them
		$query = str_replace("'", '"', $query);

		// If there isn't a specified port we use the default
		if(empty($port) || $port == "null") $port = 3306;

		// Append our port to the host for proper syntax
		$host = $host . ":" . $port;
	
		// Set up our query
		$db = mysql_connect($host, $user, $pass);
		if($db) {
			if(mysql_select_db($database)) {
				$data = array();
				$row = null;
				if($qer = mysql_query($query)) {
					while($row = mysql_fetch_assoc($qer)) {
						$data[] = $row;
					}
				} else {
					die(showError("Error running the query: " . mysql_error()));
				}
			} else {
				die(showError("Error connecting to the database: " . mysql_error()));
			}
		} else {
			die(showError("Could not connect to the database: " . mysql_error()));
		}

		// Spit back out the info
		if(!empty($data)) {
			if($_POST["view"] == "xml") {
				returnXML($data);
			} else {
				returnTable($data);
			}
		}

	}

	// Spit out the HTML version for the main runQuery function
	function returnTable($data) {
		$headers = array_keys($data[0]);
		echo "<table><tr>";
		foreach($headers as $h) {
			echo "<th>$h</th>";
		}
		echo "</tr>";
		if(!empty($data)) {
			foreach ($data as $d) {
				echo "<tr>";
				$values = array_values($d);
				foreach($values as $v) {
					echo "<td>$v</td>";
				}
				echo "</tr>";
			}
		}
	}

	// Spit out XML for the Tab Completion System
	function returnXML($data) {
		echo "
		<resultset statement='select * from admin_auth limit 1000' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>
		";

		if(!empty($data)) {
			foreach($data as $d) {
				echo "<row>";
				$keys = array_keys($d);
				foreach($keys as $k) {
					echo "<field name='$k'>$d[$k]</field>";
				}
				echo "</row>";
			}
		}

		echo "
		</resultset>
		";
	}

	// Display errors if there are any, along with any manual return messages
	function showError($e) {
		echo "<p class='error'>$e</p>";
	}


?>
